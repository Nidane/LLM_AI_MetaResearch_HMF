import json
from pathlib import Path

ext = json.loads(Path('/home/ubuntu/extract_study_characteristics.json').read_text())['results']
rob = json.loads(Path('/home/ubuntu/assess_rob2_signalling.json').read_text())['results']
ext_by = {r['output']['pmid']: r['output'] for r in ext}

human_terms = ['human milk-based fortifier','human milk based fortifier','human-derived fortifier','human milk-derived fortifier','human-derived','hmbf','hmdf','h2mf','prolacta','pasteurized human milk-derived fortifier','pasteurised human milk-derived fortifier']
bovine_terms = ['bovine milk-based fortifier','bovine milk based fortifier','bovine-derived fortifier','bovine milk-derived','cow milk-based fortifier','cow milk based fortifier',"cow's milk-based fortifier",'bmbf','bmdf','bhmf','cmbf','powdered bovine','standard bovine','cow milk-based','cow milk products']

def has_any(text, terms):
    t = (text or '').lower()
    return any(term in t for term in terms)

manual = {
    '20036378': {'eligible':'uncertain/no','reason':'Older trial appears to compare two fortifier products/diets but direct human-derived vs bovine-derived fortifier status is not clearly established from extracted fields; needs full manual check before inclusion.'},
    '2085103': {'eligible':'no','reason':'Compares human milk powder/addition with cow milk preparation in an older feeding study; not a modern human milk-derived fortifier versus bovine/cow milk-based fortifier comparison suitable for direct HMBF/BMBF meta-analysis.'},
    '23968744': {'eligible':'no','reason':'Supplementary CONSORT/image and article do not provide a direct HMBF versus BMBF fortifier comparison with usable NEC/sepsis event data.'},
    '29878061': {'eligible':'yes','reason':'Direct randomized comparison of human milk-based fortifier (HMBF) versus bovine milk-based fortifier (BMBF) with NEC and late-onset sepsis event counts.'},
    '35809401': {'eligible':'yes_narrow_nec','reason':'Direct randomized comparison of exclusive human milk-based diet/fortifier versus bovine-containing fortifier/diet; reports surgical/fatal NEC and blood-culture-positive sepsis, but not NEC any stage.'},
    '36029771': {'eligible':'yes_sepsis_only_or_unclear_nec','reason':'Direct fortifier comparison using human milk-derived fortifier versus bovine human milk fortifier terminology; reports late-onset sepsis, while NEC event counts are not clearly reported as a trial outcome in the main extracted table.'},
    '36528055': {'eligible':'no','reason':'Not a direct HMBF versus BMBF fortifier effect comparison with usable NEC/sepsis event data for this review question.'},
    '36857051': {'eligible':'yes','reason':'Direct comparison relevant to human milk-derived fortifier versus bovine milk-based control within a donor milk/fortifier trial; reports surgical NEC and late-onset sepsis/blood-culture sepsis outcomes.'},
    '38545091': {'eligible':'no_or_uncertain','reason':'Relevant neonatal nutrition trial but not clearly extractable as direct HMBF versus BMBF fortifier comparison for NEC any stage/sepsis from current extraction.'},
    '39660504': {'eligible':'yes','reason':'Direct randomized comparison of powdered human milk-derived fortifier (PHMF) versus powdered bovine milk-derived fortifier (PBMF); reports NEC and blood-culture-positive late-onset sepsis.'},
    '42045666': {'eligible':'no_primary','reason':'Exclusive human milk diet versus standard diet with formula/fortifier package; comparator includes broader diet differences, so not cleanly attributable to fortifier source alone, although safety table reports NEC and sepsis.'},
}

lines=[]
lines.append('| PMID | Author/Year | Intervention | Comparator | Human-fortifier terms? | Bovine/cow-fortifier terms? | NEC reported | Sepsis reported | Eligibility | Rationale |')
lines.append('|---|---|---|---|---:|---:|---|---|---|---|')
for pmid in sorted(ext_by, key=lambda x:int(x)):
    e=ext_by[pmid]
    text=' '.join(str(e.get(k,'')) for k in ['study_title','intervention','control','group_count_and_names','rob_outcome','numerical_result_assessed','nec_results','sepsis_results'])
    m=manual.get(pmid, {'eligible':'uncertain','reason':'Requires manual confirmation.'})
    lines.append('| {pmid} | {author} | {intervention} | {control} | {ht} | {bt} | {nec} | {sepsis} | {elig} | {reason} |'.format(
        pmid=pmid,
        author=(e.get('author_year','') or '').replace('|','/'),
        intervention=(e.get('intervention','') or '').replace('|','/'),
        control=(e.get('control','') or '').replace('|','/'),
        ht='Yes' if has_any(text,human_terms) else 'No/unclear',
        bt='Yes' if has_any(text,bovine_terms) else 'No/unclear',
        nec=(e.get('nec_reported','') or '').replace('|','/'),
        sepsis=(e.get('sepsis_reported','') or '').replace('|','/'),
        elig=m['eligible'],
        reason=m['reason'].replace('|','/'),
    ))
Path('/home/ubuntu/work_rob/hmbf_bmbf_screening_table.md').write_text('\n'.join(lines)+'\n')
print('/home/ubuntu/work_rob/hmbf_bmbf_screening_table.md')
