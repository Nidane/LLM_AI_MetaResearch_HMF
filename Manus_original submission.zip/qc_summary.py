import json
from pathlib import Path
ext=json.loads(Path('/home/ubuntu/extract_study_characteristics.json').read_text())['results']
rob=json.loads(Path('/home/ubuntu/assess_rob2_signalling.json').read_text())['results']
rob_by={r['output']['pmid']: r['output'] for r in rob}
for r in ext:
    o=r['output']; pmid=o['pmid']; ro=rob_by.get(pmid,{})
    print('\n', pmid, '|', o.get('author_year'), '|', o.get('study_title')[:80])
    print('Outcome:', o.get('rob_outcome'))
    print('Numerical:', o.get('numerical_result_assessed'))
    print('NEC:', o.get('nec_reported'), '|', o.get('nec_results')[:150])
    print('Sepsis:', o.get('sepsis_reported'), '|', o.get('sepsis_results')[:150])
    print('RoB domains:', ro.get('domain1_judgement'), ro.get('domain2_overall_judgement'), ro.get('domain3_judgement'), ro.get('domain4_judgement'), ro.get('domain5_judgement'), 'Overall:', ro.get('overall_judgement'))
    print('Errors:', r.get('error'), ro.get('error'))
