from openpyxl import load_workbook
p='/home/ubuntu/upload/Questions-1.xlsx'
wb=load_workbook(p)
print(wb.sheetnames)
for ws in wb.worksheets:
    print('SHEET', ws.title, 'rows', ws.max_row, 'cols', ws.max_column)
    for r in ws.iter_rows(min_row=1, max_row=min(ws.max_row,10), values_only=True):
        print(r)
