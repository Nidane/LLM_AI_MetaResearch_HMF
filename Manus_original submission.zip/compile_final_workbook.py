import json
import re
from pathlib import Path
from openpyxl import load_workbook, Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

TEMPLATE = Path('/home/ubuntu/upload/Questions-1.xlsx')
EXT_JSON = Path('/home/ubuntu/extract_study_characteristics.json')
ROB_JSON = Path('/home/ubuntu/assess_rob2_signalling.json')
OUT = Path('/home/ubuntu/work_rob/Completed_RoB2_Combined_Assessments.xlsx')
QC_OUT = Path('/home/ubuntu/work_rob/final_qc_notes.txt')

# Load template question order.
twb = load_workbook(TEMPLATE)
tws = twb.active
questions = [tws.cell(row=i, column=1).value for i in range(1, tws.max_row + 1)]

ext_results = json.loads(EXT_JSON.read_text())['results']
rob_results = json.loads(ROB_JSON.read_text())['results']
ext_by = {r['output']['pmid']: dict(r['output']) for r in ext_results}
rob_by = {r['output']['pmid']: dict(r['output']) for r in rob_results}

# Targeted corrections after QC review of extracted tables/images. These corrections keep the analysis aligned
# with the user's priority outcomes: NEC if numerically reported, otherwise sepsis, otherwise another primary outcome.
corrections = {
    '2085103': {
        'ext': {
            'rob_outcome': 'Necrotizing enterocolitis (NEC), because NEC was reported numerically in the complications table and occurred in neither group.',
            'numerical_result_assessed': 'NEC: HMP 0/10; CMP 0/10.',
            'nec_reported': 'Yes – NEC was listed in the complications table.',
            'nec_results': 'NEC occurred in 0 infants in the HMP group and 0 infants in the CMP group.',
        },
        'rob': {
            'q49_outcome_data_available': 'Yes – NEC was reported in the complication table for both randomized groups.',
            'q50_evidence_not_biased': 'Not applicable – data for this outcome were available for all or nearly all participants.',
            'q51_missingness_depends': 'Not applicable – data for this outcome were available for all or nearly all participants.',
            'q52_missingness_likely_depends': 'Not applicable – data for this outcome were available for all or nearly all participants.',
            'domain3_judgement': 'Low risk of bias',
            'domain3_direction': 'NA',
            'q56_inappropriate_measurement': 'No – NEC is a clinically defined neonatal morbidity and was listed as a complication.',
            'q57_measurement_differed': 'No – there was no indication that NEC ascertainment differed between groups.',
            'q58_assessors_aware': 'No information – assessor blinding was not reported.',
            'q59_knowledge_influence': 'Probably no – NEC is an objective clinical diagnosis and no cases occurred in either group.',
            'q60_influence_likely': 'Probably no – because no NEC events occurred, outcome assessment was unlikely to have been influenced by treatment knowledge.',
            'domain4_judgement': 'Low risk of bias',
            'domain4_direction': 'NA',
            'domain2_deviation_judgement': 'Some concerns',
            'domain2_analysis_judgement': 'Low risk of bias',
            'q43_appropriate_analysis': 'Probably yes – complications were tabulated by randomized group and all randomized infants appear to have contributed to the NEC result.',
            'q44_substantial_impact': 'Not applicable – an appropriate group-based analysis appears to have been used for the NEC complication result.',
            'domain2_overall_judgement': 'Some concerns',
            'overall_judgement': 'Some concerns',
            'overall_direction': 'Unpredictable – mainly due to limited reporting of allocation concealment and trial-context deviations in an older trial.',
            'rob_notes': 'The NEC result had complete event reporting and objective measurement, but the old report lacked detail on allocation concealment and deviations from intended interventions.',
        },
    },
    '35809401': {
        'ext': {
            'rob_outcome': 'Necrotising enterocolitis requiring surgery or resulting in death, because it was reported numerically in the clinical-outcome table.',
            'numerical_result_assessed': 'NEC requiring surgery or resulting in death: human-derived fortifier group 0 (0%); bovine-derived fortifier group 0 (0%).',
            'nec_reported': 'Yes – NEC requiring surgery and NEC requiring surgery or resulting in death were reported.',
            'nec_results': 'NEC requiring surgery: 0 (0%) in both groups. NEC requiring surgery or resulting in death: 0 (0%) in both groups.',
            'sepsis_reported': 'Yes – blood-culture-positive sepsis was reported.',
            'sepsis_results': 'Infants with one or more blood-culture-positive sepsis episodes: 3 (17%) vs 4 (21%), p=0.91.',
        },
        'rob': {
            'q49_outcome_data_available': 'Yes – the clinical-outcome table reported NEC for all infants reaching discharge outcomes.',
            'q50_evidence_not_biased': 'Not applicable – data for this outcome were available for all or nearly all participants.',
            'q51_missingness_depends': 'Not applicable – data for this outcome were available for all or nearly all participants.',
            'q52_missingness_likely_depends': 'Not applicable – data for this outcome were available for all or nearly all participants.',
            'domain3_judgement': 'Low risk of bias',
            'domain3_direction': 'NA',
            'q56_inappropriate_measurement': 'No – surgical or fatal NEC is a clinically objective morbidity endpoint.',
            'q57_measurement_differed': 'No – there was no indication that NEC ascertainment differed by group.',
            'q58_assessors_aware': 'No information – assessor blinding for NEC was not clearly reported.',
            'q59_knowledge_influence': 'Probably no – surgical/fatal NEC is unlikely to be materially influenced by knowledge of fortifier allocation.',
            'q60_influence_likely': 'Probably no – no NEC events occurred in either group.',
            'domain4_judgement': 'Low risk of bias',
            'domain4_direction': 'NA',
            'overall_judgement': 'Some concerns',
            'overall_direction': 'Unpredictable – remaining concerns are driven mainly by randomization/deviation reporting rather than NEC outcome measurement.',
            'rob_notes': 'For NEC, missing outcome and measurement concerns are low, but the overall rating remains Some concerns because reporting around allocation implementation and trial-context deviations was incomplete.',
        },
    },
    '39660504': {
        'ext': {
            'rob_outcome': 'Necrotising enterocolitis (medical or surgical), because NEC was reported numerically in predischarge/transfer data.',
            'numerical_result_assessed': 'NEC [surgical NEC]: PBMF/control group 0; PHMF/intervention group 1 [0 surgical], p=0.43.',
            'nec_reported': 'Yes – medical or surgical NEC was reported in the clinical-outcome table.',
            'nec_results': 'NEC [surgical NEC]: 0 in the PBMF/control group and 1 [0 surgical] in the PHMF/intervention group, p=0.43.',
            'sepsis_reported': 'Yes – blood-culture-positive late-onset sepsis was reported.',
            'sepsis_results': 'Blood-culture-positive LOS: first 21 days 0 vs 2 (14%), p=0.22; day 22 to discharge 1 (6.6%) vs 2 (14%), p=0.60.',
        },
        'rob': {
            'q49_outcome_data_available': 'Probably yes – predischarge/transfer NEC outcomes were reported by group, with deaths/transfers accounted for in the same outcome table.',
            'q50_evidence_not_biased': 'Not applicable – outcome data were available for all or nearly all participants for the reported clinical table.',
            'q51_missingness_depends': 'Not applicable – outcome data were available for all or nearly all participants for the NEC table.',
            'q52_missingness_likely_depends': 'Not applicable – outcome data were available for all or nearly all participants for the NEC table.',
            'domain3_judgement': 'Low risk of bias',
            'domain3_direction': 'NA',
            'q56_inappropriate_measurement': 'No – NEC is a defined neonatal morbidity endpoint.',
            'q57_measurement_differed': 'No – there was no evidence that NEC ascertainment differed between groups.',
            'q58_assessors_aware': 'No information – assessor blinding for NEC was not clearly described.',
            'q59_knowledge_influence': 'Probably no – NEC is a clinical morbidity endpoint and surgical NEC is objective.',
            'q60_influence_likely': 'Probably no – only one medical NEC event was reported and surgical NEC was zero.',
            'domain4_judgement': 'Low risk of bias',
            'domain4_direction': 'NA',
            'overall_judgement': 'Some concerns',
            'overall_direction': 'Unpredictable – some concerns remain due to open-label/deviation and incomplete reporting considerations.',
            'rob_notes': 'The NEC outcome itself was reported numerically with low measurement concern, but overall assessment remains Some concerns because trial-context deviation and some reporting details were incomplete.',
        },
    },
    '42045666': {
        'ext': {
            'rob_outcome': 'Bell classification stage II or higher NEC, because it was reported numerically in the safety table.',
            'numerical_result_assessed': 'Bell classification stage II or higher NEC: EHMD 1/77 (1.3%); Standard Diet 0/70 (0%).',
            'nec_reported': 'Yes – Bell classification stage II or higher NEC was reported in the safety table.',
            'nec_results': 'Bell classification stage II or higher NEC: EHMD 1 (1.3%) and Standard Diet 0 (0%).',
            'sepsis_reported': 'Yes – sepsis, septic shock, and delayed sepsis were reported as treatment-emergent or additional outcomes.',
            'sepsis_results': 'Sepsis: EHMD 1 (1.3%) vs Standard Diet 0; septic shock: EHMD 1 (1.3%) vs Standard Diet 0; delayed sepsis: EHMD 2 (2.6%) vs Standard Diet 2 (2.9%).',
        },
        'rob': {
            'q56_inappropriate_measurement': 'No – Bell stage II or higher NEC is an accepted clinical morbidity definition.',
            'q57_measurement_differed': 'No – no evidence indicated differential NEC ascertainment by group.',
            'q59_knowledge_influence': 'Probably no – stage II or higher NEC is a relatively objective clinical diagnosis, although the trial was open-label.',
            'q60_influence_likely': 'Probably no – the event count was very low and no evidence suggested influenced assessment.',
            'rob_notes': 'The open-label design drives Some concerns for deviations from intended intervention, whereas the NEC outcome was numerically reported and clinically defined.',
        },
    },
}

for pmid, corr in corrections.items():
    if pmid in ext_by:
        ext_by[pmid].update(corr.get('ext', {}))
    if pmid in rob_by:
        rob_by[pmid].update(corr.get('rob', {}))

def flag_value(flag_string, q):
    m = re.search(rf'{q}\s*=\s*([^;]+)', flag_string or '')
    return m.group(1).strip() if m else 'Not reported'

def ans(pmid):
    e = ext_by[pmid]
    r = rob_by[pmid]
    return [
        e.get('author_year',''),
        e.get('study_title',''),
        e.get('pmid',''),
        e.get('doi',''),
        e.get('study_design',''),
        flag_value(e.get('trial_type_flags',''), 'Q6'),
        flag_value(e.get('trial_type_flags',''), 'Q7'),
        flag_value(e.get('trial_type_flags',''), 'Q8'),
        flag_value(e.get('trial_type_flags',''), 'Q9'),
        e.get('country',''),
        e.get('study_population',''),
        e.get('group_count_and_names','').split(':',1)[0] if ':' in e.get('group_count_and_names','') else e.get('group_count_and_names',''),
        e.get('group_count_and_names',''),
        e.get('sample_size_total',''),
        e.get('sample_size_by_group',''),
        e.get('baseline_overall',''),
        e.get('baseline_by_group',''),
        e.get('intervention',''),
        e.get('control',''),
        e.get('rob_outcome',''),
        e.get('numerical_result_assessed',''),
        'Yes – the assessment targets the effect of assignment to intervention (intention-to-treat effect) where reported or inferable.',
        e.get('sources_for_rob',''),
        e.get('nec_reported',''),
        e.get('nec_results',''),
        e.get('sepsis_reported',''),
        e.get('sepsis_results',''),
        e.get('adverse_events_overall',''),
        e.get('adverse_events_by_group',''),
        r.get('domain1_heading','Domain 1: Randomisation process'),
        r.get('q31_random_sequence',''),
        r.get('q32_allocation_concealed',''),
        r.get('q33_baseline_differences',''),
        r.get('domain1_judgement',''),
        r.get('domain1_direction',''),
        r.get('domain2_heading','Domain 2: interventions'),
        r.get('q37_participants_aware',''),
        r.get('q38_carers_aware',''),
        r.get('q39_deviations_trial_context',''),
        r.get('q40_deviations_affected_outcome',''),
        r.get('q41_deviations_balanced',''),
        r.get('domain2_deviation_judgement',''),
        r.get('q43_appropriate_analysis',''),
        r.get('q44_substantial_impact',''),
        r.get('domain2_analysis_judgement',''),
        r.get('domain2_direction',''),
        r.get('domain2_overall_judgement',''),
        r.get('domain3_heading','Domain 3: Missing outcome data'),
        r.get('q49_outcome_data_available',''),
        r.get('q50_evidence_not_biased',''),
        r.get('q51_missingness_depends',''),
        r.get('q52_missingness_likely_depends',''),
        r.get('domain3_judgement',''),
        r.get('domain3_direction',''),
        r.get('domain4_heading','Domain 4: Risk of bias in measurement of the outcome'),
        r.get('q56_inappropriate_measurement',''),
        r.get('q57_measurement_differed',''),
        r.get('q58_assessors_aware',''),
        r.get('q59_knowledge_influence',''),
        r.get('q60_influence_likely',''),
        r.get('domain4_judgement',''),
        r.get('domain4_direction',''),
        r.get('domain5_heading','Domain 5: Risk of bias in selection of the reported result'),
        r.get('q64_prespecified_plan',''),
        'See Q66 and Q67 – selection from multiple eligible measurements and analyses was assessed below.',
        r.get('q66_multiple_measurements',''),
        r.get('q67_multiple_analyses',''),
        r.get('domain5_judgement',''),
        r.get('domain5_direction',''),
        r.get('overall_heading','Overall risk of bias'),
        r.get('overall_judgement',''),
        r.get('overall_direction',''),
        e.get('funding_source',''),
        e.get('conflicts_of_interest',''),
    ]

pmids = sorted(ext_by.keys(), key=lambda x: int(x))
wb = Workbook()
ws = wb.active
ws.title = 'Questionnaire Matrix'
ws.cell(1,1,'Question').font = Font(bold=True)
for c, pmid in enumerate(pmids, start=2):
    e = ext_by[pmid]
    ws.cell(1,c, f"{pmid} | {e.get('author_year','')}").font = Font(bold=True)
for i, q in enumerate(questions, start=2):
    ws.cell(i,1, f"{i-1}. {q}")
for c, pmid in enumerate(pmids, start=2):
    values = ans(pmid)
    if len(values) != len(questions):
        raise RuntimeError(f'{pmid}: {len(values)} values for {len(questions)} questions')
    for r_i, value in enumerate(values, start=2):
        ws.cell(r_i,c, value)

# Long format sheet.
long = wb.create_sheet('Study Rows')
headers = ['PMID', 'Author and Year'] + [f"Q{i}. {q}" for i, q in enumerate(questions, start=1)]
for c, h in enumerate(headers, start=1):
    long.cell(1,c,h).font = Font(bold=True)
for r_i, pmid in enumerate(pmids, start=2):
    values = ans(pmid)
    long.cell(r_i,1,pmid)
    long.cell(r_i,2,ext_by[pmid].get('author_year',''))
    for c, value in enumerate(values, start=3):
        long.cell(r_i,c,value)

# Summary sheet.
summary = wb.create_sheet('RoB Summary')
summary_headers = ['PMID','Author and Year','Selected outcome','Numerical result','D1','D2','D3','D4','D5','Overall','Main notes']
for c,h in enumerate(summary_headers,1):
    summary.cell(1,c,h).font=Font(bold=True)
for r_i, pmid in enumerate(pmids,2):
    e=ext_by[pmid]; r=rob_by[pmid]
    row=[pmid,e.get('author_year',''),e.get('rob_outcome',''),e.get('numerical_result_assessed',''),r.get('domain1_judgement',''),r.get('domain2_overall_judgement',''),r.get('domain3_judgement',''),r.get('domain4_judgement',''),r.get('domain5_judgement',''),r.get('overall_judgement',''),r.get('rob_notes','')]
    for c,v in enumerate(row,1): summary.cell(r_i,c,v)

# Formatting.
header_fill = PatternFill('solid', fgColor='D9EAF7')
section_fill = PatternFill('solid', fgColor='E2F0D9')
thin = Side(style='thin', color='BFBFBF')
for sheet in wb.worksheets:
    sheet.freeze_panes = 'B2' if sheet.title == 'Questionnaire Matrix' else 'A2'
    for row in sheet.iter_rows():
        for cell in row:
            cell.alignment = Alignment(wrap_text=True, vertical='top')
            cell.border = Border(left=thin,right=thin,top=thin,bottom=thin)
    for cell in sheet[1]:
        cell.fill = header_fill
        cell.font = Font(bold=True)

# Highlight domain heading rows in matrix.
for row_num in [31,37,49,56,64,71]:
    # Excel row is question number + 1 because row 1 header.
    rr = row_num + 1
    for c in range(1, ws.max_column+1):
        ws.cell(rr,c).fill = section_fill

# Widths.
ws.column_dimensions['A'].width = 48
for c in range(2, ws.max_column+1):
    ws.column_dimensions[get_column_letter(c)].width = 36
for sheet in [long, summary]:
    for c in range(1, min(sheet.max_column, 20)+1):
        sheet.column_dimensions[get_column_letter(c)].width = 28
    if sheet.max_column > 20:
        for c in range(20, sheet.max_column+1):
            sheet.column_dimensions[get_column_letter(c)].width = 24

# Basic QC notes.
qc=[]
qc.append(f'Compiled {len(pmids)} PMID groups into {OUT.name}.')
qc.append('Included sheets: Questionnaire Matrix, Study Rows, RoB Summary.')
qc.append('Questionnaire Matrix preserves the original 74-question order from Questions-1.xlsx and provides one column per PMID.')
qc.append('Study Rows provides one row per study with question-numbered columns for easier filtering.')
qc.append('Targeted QC corrections were applied for PMIDs 2085103, 35809401, 39660504, and 42045666 where the initial extraction did not prioritise a numerically reported NEC outcome.')
for pmid in pmids:
    missing = [i+1 for i,v in enumerate(ans(pmid)) if v in (None,'')]
    if missing:
        qc.append(f'{pmid}: missing answers at questions {missing}.')
    else:
        qc.append(f'{pmid}: all 74 answers populated.')
QC_OUT.write_text('\n'.join(qc)+'\n')
wb.save(OUT)
print(OUT)
print(QC_OUT)
