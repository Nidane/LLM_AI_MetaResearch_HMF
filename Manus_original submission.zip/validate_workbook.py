from openpyxl import load_workbook
from pathlib import Path
p=Path('/home/ubuntu/work_rob/Completed_RoB2_Combined_Assessments.xlsx')
wb=load_workbook(p, data_only=False)
print('Workbook:', p)
print('Sheets:', wb.sheetnames)
for ws in wb.worksheets:
    print(ws.title, ws.max_row, ws.max_column)
    # Count blank data cells excluding the question/metadata columns in key sheets.
    blank=0
    total=0
    if ws.title == 'Questionnaire Matrix':
        for row in ws.iter_rows(min_row=2, min_col=2, max_row=75, max_col=12):
            for cell in row:
                total += 1
                if cell.value in (None, ''):
                    blank += 1
    print('blank_data_cells', blank, 'of', total)
