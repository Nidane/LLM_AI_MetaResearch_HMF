import math
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill
from openpyxl.utils import get_column_letter

OUTDIR = Path('/home/ubuntu/work_rob/meta_hmbf_bmbf')
OUTDIR.mkdir(parents=True, exist_ok=True)

# Direction: RR < 1 favours human milk-based / human-derived fortifier.
# Primary set restricted to studies with a direct human milk-based/human-derived fortifier arm and a bovine/cow milk-based fortifier arm.
primary = [
    dict(pmid='29878061', study='O’Connor 2018', design_note='Direct HMBF vs BMBF randomized comparison; all infants received human milk base.',
         outcome='NEC', outcome_definition='Necrotizing enterocolitis, all stages', human_events=3, human_total=64, bovine_events=6, bovine_total=61, include_primary=True, notes='Closest match to requested NEC any-stage outcome.'),
    dict(pmid='38545091', study='Jensen 2024', design_note='Direct HMBF vs BMBF randomized comparison using targeted fortification.',
         outcome='NEC', outcome_definition='NEC stage II–III', human_events=8, human_total=115, bovine_events=9, bovine_total=113, include_primary=True, notes='Clinically significant NEC; not explicitly any-stage.'),
    dict(pmid='39660504', study='Berrington 2025', design_note='Direct PHMF vs PBMF randomized comparison.',
         outcome='NEC', outcome_definition='Medical or surgical NEC; surgical NEC shown in brackets', human_events=1, human_total=14, bovine_events=0, bovine_total=14, include_primary=True, notes='Small trial; one zero cell handled with continuity correction.'),

    dict(pmid='29878061', study='O’Connor 2018', design_note='Direct HMBF vs BMBF randomized comparison; all infants received human milk base.',
         outcome='Sepsis', outcome_definition='Late-onset sepsis confirmed by positive culture in blood, cerebrospinal fluid, or suprapubic urine ≥5 days', human_events=8, human_total=64, bovine_events=14, bovine_total=61, include_primary=True, notes='Late-onset sepsis.'),
    dict(pmid='36029771', study='Kumbhare 2022', design_note='Direct H2MF vs BHMF randomized comparison; microbiome-focused trial.',
         outcome='Sepsis', outcome_definition='Late-onset sepsis', human_events=6, human_total=16, bovine_events=2, bovine_total=14, include_primary=True, notes='Small sample; sepsis numerically reported, NEC outcome not numerically reported.'),
    dict(pmid='38545091', study='Jensen 2024', design_note='Direct HMBF vs BMBF randomized comparison using targeted fortification.',
         outcome='Sepsis', outcome_definition='Culture-proven sepsis', human_events=33, human_total=115, bovine_events=28, bovine_total=113, include_primary=True, notes='Culture-proven sepsis.'),
    dict(pmid='39660504', study='Berrington 2025', design_note='Direct PHMF vs PBMF randomized comparison.',
         outcome='Sepsis', outcome_definition='Blood-culture-positive late-onset sepsis in first 21 study days', human_events=2, human_total=14, bovine_events=0, bovine_total=14, include_primary=True, notes='Used first-21-day row because later period was reported separately and may not give unique all-follow-up infant counts.'),
]

# Sensitivity set: broader exclusive-human-milk-diet package trials, not clean fortifier-only comparisons.
sensitivity_broader = [
    dict(pmid='35809401', study='Uthaya 2022', design_note='Exclusive human milk diet with Prolacta products vs mother’s milk plus cow milk-derived fortifier/preterm formula; broader diet package.',
         outcome='NEC', outcome_definition='NEC requiring surgery or resulting in death', human_events=0, human_total=18, bovine_events=0, bovine_total=19, include_primary=False, notes='Double-zero study; not estimable for RR without continuity correction and not a clean fortifier-only comparison.'),
    dict(pmid='35809401', study='Uthaya 2022', design_note='Exclusive human milk diet with Prolacta products vs mother’s milk plus cow milk-derived fortifier/preterm formula; broader diet package.',
         outcome='Sepsis', outcome_definition='One or more episodes of blood-culture-positive sepsis', human_events=3, human_total=18, bovine_events=4, bovine_total=19, include_primary=False, notes='Broader diet package, not clean fortifier-only comparison.'),
    dict(pmid='36857051', study='Embleton 2023', design_note='Exclusive human milk diet using donor milk plus human-derived fortifier vs formula shortfall plus bovine-derived fortifier; broader diet package.',
         outcome='NEC', outcome_definition='Surgical NEC', human_events=1, human_total=63, bovine_events=2, bovine_total=63, include_primary=False, notes='Broader diet package and narrow NEC definition.'),
    dict(pmid='36857051', study='Embleton 2023', design_note='Exclusive human milk diet using donor milk plus human-derived fortifier vs formula shortfall plus bovine-derived fortifier; broader diet package.',
         outcome='Sepsis', outcome_definition='Blood-culture-positive late-onset sepsis', human_events=6, human_total=63, bovine_events=8, bovine_total=63, include_primary=False, notes='Broader diet package, not clean fortifier-only comparison.'),
]

screening = [
    dict(pmid='2085103', status='Excluded from primary meta-analysis', reason='Older human milk protein versus cow milk protein fortification study; not a modern HMBF/BMBF comparison; NEC 0/10 vs 0/10 is double-zero and uninformative for RR.'),
    dict(pmid='20036378', status='Excluded from primary; possible broader-diet sensitivity only', reason='Human milk-derived fortifier arms also used donor human milk when mother’s milk unavailable; bovine arm also used preterm formula. Effect is an exclusive-human-milk-diet package, not fortifier source alone.'),
    dict(pmid='23968744', status='Excluded', reason='Comparator was bovine preterm formula rather than bovine/cow milk-based fortifier; not a direct fortifier comparison.'),
    dict(pmid='29878061', status='Included primary', reason='Direct human milk-based fortifier versus bovine milk-based fortifier with NEC and sepsis counts.'),
    dict(pmid='35809401', status='Excluded primary; included broader-diet sensitivity', reason='Human-derived products versus cow milk-derived fortifier plus preterm formula; not cleanly attributable to fortifier source alone; reports surgical/fatal NEC and sepsis.'),
    dict(pmid='36029771', status='Included primary for sepsis only', reason='Direct H2MF versus BHMF with late-onset sepsis counts; no numerically reported NEC outcome.'),
    dict(pmid='36528055', status='Excluded', reason='Comparator was formula-based standard fortification rather than a clean BMBF arm with usable direct NEC/sepsis counts.'),
    dict(pmid='36857051', status='Excluded primary; included broader-diet sensitivity', reason='Exclusive-human-milk-diet package including donor milk and human-derived fortifier versus formula shortfall and bovine fortifier; not fortifier-only.'),
    dict(pmid='38545091', status='Included primary', reason='Direct HMBF versus BMBF with NEC II–III and culture-proven sepsis counts.'),
    dict(pmid='39660504', status='Included primary', reason='Direct powdered human milk-derived fortifier versus powdered bovine milk-derived fortifier with NEC and blood-culture-positive LOS counts.'),
    dict(pmid='42045666', status='Excluded primary', reason='Exclusive human milk diet versus standard diet; comparator includes cow milk-based fortifier and/or preterm formula, so not clean fortifier-only.'),
]

synonyms = pd.DataFrame([
    {'concept':'Human-based milk fortifier', 'terms':'human milk-based fortifier; human-derived human milk fortifier; human milk-derived fortifier; human milk-based human milk fortifier; human milk-based diet fortifier; HMBF; HMDF; H2MF; PHMF; Prolacta/Prolact+ H2MF context; Humavant; Neokare PHMF; Prolacta products used as fortifier'},
    {'concept':'Bovine/cow milk-based fortifier', 'terms':'bovine milk-based fortifier; bovine-derived human milk fortifier; bovine origin fortifier; cow milk-based fortifier; cow milk derived fortifier; bovine milk-derived fortification; BMBF; BMDF; BHMF; PBMF; CMBF; powdered bovine milk-based fortifier; standard bovine human milk fortifier'},
])

def study_effect(row):
    a = row['human_events']; n1 = row['human_total']; c = row['bovine_events']; n0 = row['bovine_total']
    b = n1 - a; d = n0 - c
    corrected = False
    aa, bb, cc, dd = map(float, (a,b,c,d))
    if min(aa, bb, cc, dd) == 0:
        aa += 0.5; bb += 0.5; cc += 0.5; dd += 0.5
        corrected = True
    rr = (aa/(aa+bb))/(cc/(cc+dd))
    logrr = math.log(rr)
    var = (1/aa) - (1/(aa+bb)) + (1/cc) - (1/(cc+dd))
    se = math.sqrt(var)
    lcl = math.exp(logrr - 1.96*se)
    ucl = math.exp(logrr + 1.96*se)
    return pd.Series({'rr': rr, 'log_rr': logrr, 'var_log_rr': var, 'se_log_rr': se, 'ci_low': lcl, 'ci_high': ucl, 'continuity_correction': corrected})

def pool_iv(df):
    yi = df['log_rr'].to_numpy(float); vi = df['var_log_rr'].to_numpy(float)
    wi = 1/vi
    fixed_mu = np.sum(wi*yi)/np.sum(wi)
    fixed_var = 1/np.sum(wi)
    q = np.sum(wi*(yi-fixed_mu)**2)
    k = len(yi)
    c = np.sum(wi) - np.sum(wi**2)/np.sum(wi)
    tau2 = max(0, (q-(k-1))/c) if k > 1 and c > 0 else 0.0
    wi_re = 1/(vi+tau2)
    re_mu = np.sum(wi_re*yi)/np.sum(wi_re)
    re_var = 1/np.sum(wi_re)
    i2 = max(0, (q-(k-1))/q)*100 if q > 0 and k > 1 else 0.0
    return {
        'k': k,
        'fixed_rr': math.exp(fixed_mu), 'fixed_ci_low': math.exp(fixed_mu-1.96*math.sqrt(fixed_var)), 'fixed_ci_high': math.exp(fixed_mu+1.96*math.sqrt(fixed_var)),
        'random_rr': math.exp(re_mu), 'random_ci_low': math.exp(re_mu-1.96*math.sqrt(re_var)), 'random_ci_high': math.exp(re_mu+1.96*math.sqrt(re_var)),
        'tau2_dl': tau2, 'q': q, 'i2_percent': i2,
    }

def analyse(records, label):
    df = pd.DataFrame(records)
    eff = df.apply(study_effect, axis=1)
    df = pd.concat([df, eff], axis=1)
    pools = []
    for outcome in ['NEC','Sepsis']:
        odf = df[df['outcome']==outcome].copy()
        # For double-zero broader studies, RR estimates are technically continuity-corrected; retain only in sensitivity if explicitly supplied.
        if len(odf) >= 2:
            p = pool_iv(odf)
            p['analysis_set'] = label
            p['outcome'] = outcome
            pools.append(p)
    return df, pd.DataFrame(pools)

primary_df, primary_pool = analyse(primary, 'Primary direct fortifier comparison')
broader_df, broader_pool = analyse(primary + sensitivity_broader, 'Sensitivity including broader diet-package comparisons')
all_data = pd.concat([primary_df.assign(analysis_set='Primary direct fortifier comparison'), broader_df[broader_df['include_primary']==False].assign(analysis_set='Broader diet-package sensitivity only')], ignore_index=True)
pool_df = pd.concat([primary_pool, broader_pool], ignore_index=True)

# Save datasets
primary_df.to_csv(OUTDIR/'primary_event_data.csv', index=False)
all_data.to_csv(OUTDIR/'all_event_data_with_sensitivity.csv', index=False)
pool_df.to_csv(OUTDIR/'pooled_results.csv', index=False)
pd.DataFrame(screening).to_csv(OUTDIR/'screening_decisions.csv', index=False)
synonyms.to_csv(OUTDIR/'synonym_framework.csv', index=False)

# Forest plot function.
def forest_plot(df, pool_row, outcome, filename, title):
    odf = df[df['outcome']==outcome].copy().reset_index(drop=True)
    n = len(odf)
    fig_h = max(4.5, 1.0*n + 2.5)
    fig, ax = plt.subplots(figsize=(9, fig_h))
    y = np.arange(n, 0, -1)
    ax.errorbar(odf['rr'], y, xerr=[odf['rr']-odf['ci_low'], odf['ci_high']-odf['rr']], fmt='o', color='#1f77b4', ecolor='#1f77b4', capsize=3)
    ax.axvline(1, color='black', lw=1)
    pooled = pool_row.iloc[0]
    ax.errorbar(pooled['random_rr'], 0, xerr=[[pooled['random_rr']-pooled['random_ci_low']], [pooled['random_ci_high']-pooled['random_rr']]], fmt='D', color='#d62728', ecolor='#d62728', markersize=7, capsize=5)
    labels = [f"{r.study} ({int(r.human_events)}/{int(r.human_total)} vs {int(r.bovine_events)}/{int(r.bovine_total)})" for r in odf.itertuples()]
    ax.set_yticks(list(y)+[0])
    ax.set_yticklabels(labels + ['Random-effects pooled'])
    ax.set_xscale('log')
    vals = list(odf['ci_low']) + list(odf['ci_high']) + [pooled['random_ci_low'], pooled['random_ci_high']]
    xmin = max(0.02, min(vals)*0.55)
    xmax = max(vals)*1.8
    ax.set_xlim(xmin, xmax)
    ax.set_xlabel('Risk ratio (human milk-based fortifier / bovine-cow milk-based fortifier)')
    ax.set_title(title)
    ax.grid(axis='x', which='both', linestyle=':', alpha=0.5)
    ax.text(0.01, -0.12, 'RR < 1 favours human milk-based fortifier. Continuity correction used for single-zero cells.', transform=ax.transAxes, fontsize=9)
    fig.tight_layout()
    fig.savefig(OUTDIR/filename, dpi=200, bbox_inches='tight')
    plt.close(fig)

for outcome in ['NEC','Sepsis']:
    pr = primary_pool[(primary_pool['analysis_set']=='Primary direct fortifier comparison') & (primary_pool['outcome']==outcome)]
    if not pr.empty:
        forest_plot(primary_df, pr, outcome, f'forest_primary_{outcome.lower()}.png', f'Primary direct fortifier comparison: {outcome}')
    sr = broader_pool[(broader_pool['analysis_set']=='Sensitivity including broader diet-package comparisons') & (broader_pool['outcome']==outcome)]
    if not sr.empty:
        forest_plot(broader_df, sr, outcome, f'forest_sensitivity_{outcome.lower()}.png', f'Sensitivity including broader diet-package comparisons: {outcome}')

# Excel workbook
wb = Workbook()
ws = wb.active
ws.title = 'Summary'
summary_rows = [
    ['Question', 'Assessment'],
    ['Is a direct meta-analysis feasible?', 'Yes, but with important limitations. Direct fortifier-source event data are extractable for sepsis from four direct trials and for NEC from three direct trials. NEC definitions are not uniformly “any stage”; only O’Connor 2018 explicitly reports all-stage NEC, while Jensen 2024 reports NEC II–III and Berrington 2025 reports medical/surgical NEC.'],
    ['Primary interpretation', 'Use the primary direct-fortifier analysis for the requested comparison. Treat NEC as “reported NEC, closest available definition” rather than a perfectly uniform any-stage endpoint.'],
    ['Direction of effect', 'Risk ratio < 1 favours human milk-based/human-derived fortifier; risk ratio > 1 favours bovine/cow milk-based fortifier.'],
]
for row in summary_rows:
    ws.append(row)
ws['A1'].font = ws['B1'].font = Font(bold=True)
ws.column_dimensions['A'].width = 35
ws.column_dimensions['B'].width = 120
ws['B2'].alignment = ws['B3'].alignment = ws['B4'].alignment = Alignment(wrap_text=True, vertical='top')

def add_df_sheet(name, df):
    ws = wb.create_sheet(name[:31])
    ws.append(list(df.columns))
    for cell in ws[1]:
        cell.font = Font(bold=True)
        cell.fill = PatternFill('solid', fgColor='D9EAF7')
        cell.alignment = Alignment(wrap_text=True, vertical='top')
    for _, row in df.iterrows():
        ws.append([row[c] for c in df.columns])
    for col_idx, col in enumerate(df.columns, start=1):
        width = min(60, max(12, len(str(col))+2, *(len(str(v)) for v in df[col].head(20)))+2)
        ws.column_dimensions[get_column_letter(col_idx)].width = width
    for row in ws.iter_rows():
        for cell in row:
            cell.alignment = Alignment(wrap_text=True, vertical='top')
    return ws

add_df_sheet('Primary event data', primary_df)
add_df_sheet('Pooled results', pool_df)
add_df_sheet('All event data', all_data)
add_df_sheet('Screening decisions', pd.DataFrame(screening))
add_df_sheet('Synonym framework', synonyms)
wb.save(OUTDIR/'HMBF_vs_BMBF_meta_analysis.xlsx')

# Markdown report
fmt = lambda x: f"{x:.2f}"
report = []
report.append('# Meta-analysis Feasibility and Results: Human Milk-Based Fortifier versus Bovine/Cow Milk-Based Fortifier\n')
report.append('**Author:** Manus AI\n')
report.append('## Bottom line\n')
report.append('A direct quantitative meta-analysis is **feasible for sepsis** and **partly feasible for NEC**, using the uploaded trials with direct human milk-based or human-derived fortifier versus bovine/cow milk-based fortifier comparisons. The main limitation is that the NEC endpoint is **not uniformly reported as “any stage”** across the direct trials. Therefore, the primary NEC synthesis should be interpreted as **reported NEC using the closest extractable definition** rather than as a perfectly homogeneous any-stage NEC endpoint.\n')
report.append('## Synonym framework used for screening\n')
report.append('| Concept | Synonym terms treated as relevant |\n|---|---|\n')
for _, r in synonyms.iterrows():
    report.append(f"| {r['concept']} | {r['terms']} |\n")
report.append('\n## Primary direct-comparison event data\n')
cols = ['pmid','study','outcome','outcome_definition','human_events','human_total','bovine_events','bovine_total','notes']
report.append(primary_df[cols].to_markdown(index=False))
report.append('\n\n## Primary pooled results\n')
res_rows=[]
for _, r in primary_pool.iterrows():
    res_rows.append({
        'Outcome': r['outcome'], 'Studies': int(r['k']),
        'Random-effects RR (95% CI)': f"{r['random_rr']:.2f} ({r['random_ci_low']:.2f} to {r['random_ci_high']:.2f})",
        'Fixed-effect RR (95% CI)': f"{r['fixed_rr']:.2f} ({r['fixed_ci_low']:.2f} to {r['fixed_ci_high']:.2f})",
        'I²': f"{r['i2_percent']:.1f}%", 'Tau²': f"{r['tau2_dl']:.3f}",
    })
report.append(pd.DataFrame(res_rows).to_markdown(index=False))
report.append('\n\n![Primary NEC forest plot](forest_primary_nec.png)\n\n![Primary sepsis forest plot](forest_primary_sepsis.png)\n')
report.append('## Interpretation\n')
for _, r in primary_pool.iterrows():
    direction = 'favours human milk-based fortifier' if r['random_rr'] < 1 else 'favours bovine/cow milk-based fortifier'
    report.append(f"For **{r['outcome']}**, the random-effects pooled RR was **{r['random_rr']:.2f}** (95% CI **{r['random_ci_low']:.2f} to {r['random_ci_high']:.2f}**), with I² = **{r['i2_percent']:.1f}%**; numerically this {direction}, but the confidence interval should be considered when judging certainty.\n")
report.append('\n## Eligibility decisions\n')
report.append(pd.DataFrame(screening).to_markdown(index=False))
report.append('\n\n## Sensitivity analysis including broader diet-package studies\n')
report.append('The sensitivity analysis adds studies in which the comparison included an **exclusive human milk diet package** rather than fortifier source alone. These studies are biologically relevant but are not clean direct estimates of fortifier source because donor milk and/or preterm formula exposure differed by arm.\n')
sens_rows=[]
for _, r in broader_pool.iterrows():
    sens_rows.append({
        'Outcome': r['outcome'], 'Studies': int(r['k']),
        'Analysis set': r['analysis_set'],
        'Random-effects RR (95% CI)': f"{r['random_rr']:.2f} ({r['random_ci_low']:.2f} to {r['random_ci_high']:.2f})",
        'I²': f"{r['i2_percent']:.1f}%",
    })
report.append(pd.DataFrame(sens_rows).to_markdown(index=False))
report.append('\n\n![Sensitivity NEC forest plot](forest_sensitivity_nec.png)\n\n![Sensitivity sepsis forest plot](forest_sensitivity_sepsis.png)\n')
report.append('## Important cautions\n')
report.append('The NEC meta-analysis is limited by **endpoint heterogeneity**, because all-stage NEC, NEC II–III, medical/surgical NEC, and surgical/fatal NEC are not identical clinical endpoints. The sepsis meta-analysis is more consistently extractable, but definitions still vary between late-onset sepsis, blood-culture-positive LOS, and culture-proven sepsis. The analysis uses unadjusted event counts, because adjusted estimates were not consistently reported across all direct-comparison studies. Single-zero cells were handled by a standard 0.5 continuity correction for log-risk-ratio estimation.\n')
report.append('## Files generated\n')
report.append('The accompanying Excel workbook contains the primary event-count dataset, screening decisions, synonym framework, and pooled results. CSV files and forest plots are also included for reproducibility.\n')

(OUTDIR/'HMBF_vs_BMBF_meta_analysis_report.md').write_text('\n'.join(report), encoding='utf-8')
print('Generated files in', OUTDIR)
print(pool_df.to_string(index=False))
