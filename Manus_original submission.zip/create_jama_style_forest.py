from pathlib import Path
import math
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
from matplotlib.lines import Line2D

BASE = Path('/home/ubuntu/work_rob/meta_hmbf_bmbf')
OUT = BASE / 'jama_style_plots'
OUT.mkdir(parents=True, exist_ok=True)

events = pd.read_csv(BASE / 'primary_event_data.csv')
pooled = pd.read_csv(BASE / 'pooled_results.csv')
events = events[events['include_primary'].astype(str).str.lower().eq('true')].copy()
events = events[events['outcome'].isin(['NEC', 'Sepsis'])].copy()

# Compute random-effects weights within each outcome, matching the pooled random-effects model.
tau_map = pooled[pooled['analysis_set'].eq('Primary direct fortifier comparison')].set_index('outcome')['tau2_dl'].to_dict()
events['tau2'] = events['outcome'].map(tau_map).fillna(0.0)
events['random_weight_raw'] = 1 / (events['var_log_rr'] + events['tau2'])
events['weight_percent'] = events.groupby('outcome')['random_weight_raw'].transform(lambda s: 100 * s / s.sum())

# Display helpers.
def fmt_rr(row):
    return f"{row['rr']:.2f} ({row['ci_low']:.2f}-{row['ci_high']:.2f})"

def fmt_pool(outcome):
    r = pooled[(pooled['analysis_set'].eq('Primary direct fortifier comparison')) & (pooled['outcome'].eq(outcome))].iloc[0]
    return f"{r['random_rr']:.2f} ({r['random_ci_low']:.2f}-{r['random_ci_high']:.2f})"

def safe_label(label):
    return str(label).replace('O’', "O'")

# Build a single combined JAMA-style figure with outcome subgroups.
rows = []
for outcome in ['NEC', 'Sepsis']:
    rows.append({'type': 'group', 'outcome': outcome, 'label': outcome})
    sub = events[events['outcome'].eq(outcome)].copy()
    for _, row in sub.iterrows():
        rows.append({'type': 'study', 'outcome': outcome, **row.to_dict()})
    r = pooled[(pooled['analysis_set'].eq('Primary direct fortifier comparison')) & (pooled['outcome'].eq(outcome))].iloc[0]
    rows.append({'type': 'summary', 'outcome': outcome, 'label': 'Random effects model',
                 'rr': r['random_rr'], 'ci_low': r['random_ci_low'], 'ci_high': r['random_ci_high'],
                 'human_total': int(sub['human_total'].sum()), 'bovine_total': int(sub['bovine_total'].sum()),
                 'weight_percent': 100.0, 'tau2': r['tau2_dl'], 'i2_percent': r['i2_percent']})
    rows.append({'type': 'heterogeneity', 'outcome': outcome, 'label': f"Heterogeneity: I² = {r['i2_percent']:.1f}%; τ² = {r['tau2_dl']:.3f}"})
    rows.append({'type': 'spacer'})

n = len(rows)
# y positions: top to bottom, with additional space for headers.
y_positions = list(range(n, 0, -1))
for row, y in zip(rows, y_positions):
    row['y'] = y

# Figure geometry chosen to resemble the JAMA figure: broad table area on left and forest area on right.
fig = plt.figure(figsize=(13.6, 7.9), dpi=300)
left_ax = fig.add_axes([0.035, 0.10, 0.58, 0.80])
forest_ax = fig.add_axes([0.62, 0.10, 0.25, 0.80])
weight_ax = fig.add_axes([0.875, 0.10, 0.095, 0.80])
for ax in [left_ax, weight_ax]:
    ax.set_xlim(0, 1)
    ax.set_ylim(0, n + 2.2)
    ax.axis('off')

forest_ax.set_ylim(0, n + 2.2)
forest_ax.set_xscale('log')
forest_ax.set_xlim(0.1, 100)
forest_ax.set_yticks([])
forest_ax.spines[['left', 'right', 'top']].set_visible(False)
forest_ax.spines['bottom'].set_linewidth(0.7)
forest_ax.tick_params(axis='x', labelsize=9, width=0.6, length=3)
forest_ax.set_xticks([0.1, 0.2, 0.5, 1, 2, 5, 10, 100])
forest_ax.set_xticklabels(['0.1', '0.2', '0.5', '1', '2', '5', '10', '100'])
forest_ax.axvline(1, color='black', lw=0.8, zorder=1)
forest_ax.set_xlabel('Risk ratio (95% CI)', fontsize=10)

# Header positions and labels.
header_y = n + 1.35
rule_y = n + 0.85
left_ax.text(0.00, header_y, 'Source', fontsize=10, fontweight='bold', va='bottom')
left_ax.text(0.33, header_y + 0.30, 'Human\nmilk-based\nfortifier', fontsize=9.5, fontweight='bold', va='bottom', ha='center', linespacing=1.05)
left_ax.text(0.33, header_y - 0.10, 'Events/total', fontsize=8.8, fontweight='bold', va='bottom', ha='center')
left_ax.text(0.51, header_y + 0.30, 'Bovine/cow\nmilk-based\nfortifier', fontsize=9.5, fontweight='bold', va='bottom', ha='center', linespacing=1.05)
left_ax.text(0.51, header_y - 0.10, 'Events/total', fontsize=8.8, fontweight='bold', va='bottom', ha='center')
left_ax.text(0.73, header_y, 'Risk ratio\n(95% CI)', fontsize=10, fontweight='bold', va='bottom', ha='center')
forest_ax.text(0.22, header_y + 0.25, 'Favors human\nmilk-based\nfortifier', fontsize=9, ha='center', va='bottom')
forest_ax.text(4.5, header_y + 0.25, 'Favors bovine/cow\nmilk-based\nfortifier', fontsize=9, ha='center', va='bottom')
weight_ax.text(0.98, header_y, 'Weight, %', fontsize=10, fontweight='bold', va='bottom', ha='right')

# Header separator rules.
for ax in [left_ax, forest_ax, weight_ax]:
    ax.axhline(rule_y, color='black', lw=0.8, clip_on=False)

# Light row separators, JAMA-like.
sep_color = '#dddddd'
for row in rows:
    y = row['y']
    if row.get('type') != 'spacer':
        for ax in [left_ax, forest_ax, weight_ax]:
            ax.axhline(y - 0.52, color=sep_color, lw=0.55, zorder=0)

# Reference dashed pooled lines by outcome.
for outcome in ['NEC', 'Sepsis']:
    pool_rr = float(pooled[(pooled['analysis_set'].eq('Primary direct fortifier comparison')) & (pooled['outcome'].eq(outcome))]['random_rr'].iloc[0])
    ys = [r['y'] for r in rows if r.get('outcome') == outcome and r.get('type') in {'study', 'summary'}]
    forest_ax.vlines(pool_rr, min(ys)-0.3, max(ys)+0.3, color='#555555', lw=0.8, ls='--', zorder=1)

# Row drawing.
study_color = '#2f5963'  # dark teal, close to JAMA example
summary_color = '#a9c8d3'  # light blue diamond
ci_color = '#8a8a8a'
for row in rows:
    typ = row.get('type')
    y = row['y']
    if typ == 'group':
        left_ax.text(0.00, y, row['label'], fontsize=10, va='center')
    elif typ == 'study':
        left_ax.text(0.02, y, safe_label(row['study']), fontsize=9.2, va='center')
        left_ax.text(0.33, y, f"{int(row['human_events'])}/{int(row['human_total'])}", fontsize=9.2, va='center', ha='center')
        left_ax.text(0.51, y, f"{int(row['bovine_events'])}/{int(row['bovine_total'])}", fontsize=9.2, va='center', ha='center')
        left_ax.text(0.73, y, fmt_rr(row), fontsize=9.2, va='center', ha='center')
        weight_ax.text(0.98, y, f"{row['weight_percent']:.1f}", fontsize=9.2, va='center', ha='right')
        lo, hi, rr = float(row['ci_low']), float(row['ci_high']), float(row['rr'])
        x_min, x_max = forest_ax.get_xlim()
        lo_clip, hi_clip = max(lo, x_min), min(hi, x_max)
        forest_ax.hlines(y, lo_clip, hi_clip, color=ci_color, lw=0.85, zorder=2)
        # Add small outward arrows if CI exceeds plotting limits.
        if lo < x_min:
            forest_ax.plot(x_min, y, marker='<', color=ci_color, markersize=3.5, clip_on=False)
        if hi > x_max:
            forest_ax.plot(x_max, y, marker='>', color=ci_color, markersize=3.5, clip_on=False)
        size = 18 + 1.7 * row['weight_percent']
        forest_ax.scatter(rr, y, s=size, marker='s', color=study_color, edgecolor=study_color, zorder=3)
    elif typ == 'summary':
        left_ax.text(0.02, y, row['label'], fontsize=9.4, va='center')
        left_ax.text(0.33, y, f"{int(row['human_total'])}", fontsize=9.4, va='center', ha='center')
        left_ax.text(0.51, y, f"{int(row['bovine_total'])}", fontsize=9.4, va='center', ha='center')
        left_ax.text(0.73, y, f"{row['rr']:.2f} ({row['ci_low']:.2f}-{row['ci_high']:.2f})", fontsize=9.4, va='center', ha='center')
        weight_ax.text(0.98, y, '100.0', fontsize=9.4, va='center', ha='right')
        lo, hi, rr = float(row['ci_low']), float(row['ci_high']), float(row['rr'])
        dy = 0.28
        diamond = np.array([[lo, y], [rr, y + dy], [hi, y], [rr, y - dy]])
        forest_ax.add_patch(Polygon(diamond, closed=True, facecolor=summary_color, edgecolor=study_color, lw=0.8, zorder=4))
    elif typ == 'heterogeneity':
        left_ax.text(0.02, y, row['label'], fontsize=9, va='center')

fig.suptitle('Human Milk-Based Fortifier vs Bovine/Cow Milk-Based Fortifier: Primary Direct-Comparison Meta-analysis',
             fontsize=12.5, y=0.985, fontweight='bold')
fig.text(0.62, 0.045, 'RR < 1 favors human milk-based fortifier; RR > 1 favors bovine/cow milk-based fortifier.\nSingle-zero cells use a 0.5 continuity correction; estimates are random-effects pooled risk ratios.',
         fontsize=8.6, ha='left', va='top')

for ext in ['png', 'pdf', 'svg']:
    fig.savefig(OUT / f'jama_style_primary_forest.{ext}', bbox_inches='tight')
plt.close(fig)

# Also generate outcome-specific figures in the same style, useful for manuscripts when a single compact figure is preferred.
def make_single_outcome(outcome):
    sub = events[events['outcome'].eq(outcome)].copy()
    r = pooled[(pooled['analysis_set'].eq('Primary direct fortifier comparison')) & (pooled['outcome'].eq(outcome))].iloc[0]
    local_rows = [{'type':'group','label':outcome}]
    for _, row in sub.iterrows():
        local_rows.append({'type':'study', **row.to_dict()})
    local_rows.append({'type':'summary','label':'Random effects model','rr':r['random_rr'], 'ci_low':r['random_ci_low'], 'ci_high':r['random_ci_high'], 'human_total':int(sub['human_total'].sum()), 'bovine_total':int(sub['bovine_total'].sum()), 'weight_percent':100.0})
    local_rows.append({'type':'heterogeneity','label':f"Heterogeneity: I² = {r['i2_percent']:.1f}%; τ² = {r['tau2_dl']:.3f}"})
    n2 = len(local_rows)
    for row, y in zip(local_rows, range(n2, 0, -1)):
        row['y']=y
    fig = plt.figure(figsize=(12.5, 4.35 if outcome == 'NEC' else 4.55), dpi=300)
    la = fig.add_axes([0.035, 0.27, 0.58, 0.60])
    fa = fig.add_axes([0.62, 0.27, 0.25, 0.60])
    wa = fig.add_axes([0.875, 0.27, 0.095, 0.60])
    for ax in [la, wa]:
        ax.set_xlim(0,1); ax.set_ylim(0,n2+2.2); ax.axis('off')
    fa.set_ylim(0,n2+2.2); fa.set_xscale('log'); fa.set_xlim(0.1,100); fa.set_yticks([])
    fa.spines[['left','right','top']].set_visible(False); fa.spines['bottom'].set_linewidth(0.7)
    fa.set_xticks([0.1,0.2,0.5,1,2,5,10,100]); fa.set_xticklabels(['0.1','0.2','0.5','1','2','5','10','100'], fontsize=8.5)
    fa.axvline(1,color='black',lw=0.8); fa.axvline(r['random_rr'], color='#555555', lw=0.8, ls='--')
    fa.set_xlabel('Risk ratio (95% CI)', fontsize=9.5, labelpad=8)
    hy=n2+1.25; ry=n2+0.75
    la.text(0,hy,'Source',fontsize=9.5,fontweight='bold',va='bottom')
    la.text(0.33,hy,'Human\nmilk-based\nEvents/total',fontsize=8.8,fontweight='bold',va='bottom',ha='center',linespacing=1.05)
    la.text(0.51,hy,'Bovine/cow\nmilk-based\nEvents/total',fontsize=8.8,fontweight='bold',va='bottom',ha='center',linespacing=1.05)
    la.text(0.73,hy,'Risk ratio\n(95% CI)',fontsize=9.5,fontweight='bold',va='bottom',ha='center')
    fa.text(0.22, hy+0.05, 'Favors human\nfortifier', fontsize=8.5, ha='center', va='bottom')
    fa.text(4.5, hy+0.05, 'Favors bovine/cow\nfortifier', fontsize=8.5, ha='center', va='bottom')
    wa.text(0.98,hy,'Weight, %',fontsize=9.5,fontweight='bold',va='bottom',ha='right')
    for ax in [la,fa,wa]: ax.axhline(ry,color='black',lw=0.8,clip_on=False)
    for row in local_rows:
        if row['type']!='spacer':
            for ax in [la,fa,wa]: ax.axhline(row['y']-0.52,color=sep_color,lw=0.55,zorder=0)
    for row in local_rows:
        y=row['y']; typ=row['type']
        if typ=='group':
            la.text(0,y,row['label'],fontsize=9.6,va='center')
        elif typ=='study':
            la.text(0.02,y,safe_label(row['study']),fontsize=9,va='center')
            la.text(0.33,y,f"{int(row['human_events'])}/{int(row['human_total'])}",fontsize=9,va='center',ha='center')
            la.text(0.51,y,f"{int(row['bovine_events'])}/{int(row['bovine_total'])}",fontsize=9,va='center',ha='center')
            la.text(0.73,y,fmt_rr(row),fontsize=9,va='center',ha='center')
            wa.text(0.98,y,f"{row['weight_percent']:.1f}",fontsize=9,va='center',ha='right')
            lo,hi,rr=float(row['ci_low']),float(row['ci_high']),float(row['rr'])
            fa.hlines(y,max(lo,0.1),min(hi,100),color=ci_color,lw=0.85,zorder=2)
            if hi>100: fa.plot(100,y,marker='>',color=ci_color,markersize=3.5,clip_on=False)
            if lo<0.1: fa.plot(0.1,y,marker='<',color=ci_color,markersize=3.5,clip_on=False)
            fa.scatter(rr,y,s=18+1.7*row['weight_percent'],marker='s',color=study_color,edgecolor=study_color,zorder=3)
        elif typ=='summary':
            la.text(0.02,y,row['label'],fontsize=9.2,va='center')
            la.text(0.33,y,f"{int(row['human_total'])}",fontsize=9.2,va='center',ha='center')
            la.text(0.51,y,f"{int(row['bovine_total'])}",fontsize=9.2,va='center',ha='center')
            la.text(0.73,y,f"{row['rr']:.2f} ({row['ci_low']:.2f}-{row['ci_high']:.2f})",fontsize=9.2,va='center',ha='center')
            wa.text(0.98,y,'100.0',fontsize=9.2,va='center',ha='right')
            dy=0.25; diamond=np.array([[row['ci_low'],y],[row['rr'],y+dy],[row['ci_high'],y],[row['rr'],y-dy]])
            fa.add_patch(Polygon(diamond,closed=True,facecolor=summary_color,edgecolor=study_color,lw=0.8,zorder=4))
        elif typ=='heterogeneity':
            la.text(0.02,y,row['label'],fontsize=8.8,va='center')
    fig.suptitle(f'{outcome}: Human Milk-Based Fortifier vs Bovine/Cow Milk-Based Fortifier', fontsize=11.5, y=0.98, fontweight='bold')
    fig.text(0.62,0.035,'RR < 1 favors human milk-based fortifier; RR > 1 favors bovine/cow milk-based fortifier.',fontsize=8.3,ha='left', va='bottom')
    for ext in ['png','pdf','svg']:
        fig.savefig(OUT / f'jama_style_{outcome.lower()}_forest.{ext}', bbox_inches='tight')
    plt.close(fig)

for outcome in ['NEC','Sepsis']:
    make_single_outcome(outcome)

# Save the plot data used for reproduction.
events.to_csv(OUT / 'jama_style_primary_plot_data.csv', index=False)
print(f'Generated JAMA-style plots in {OUT}')
for p in sorted(OUT.iterdir()):
    print(p.name, p.stat().st_size)
