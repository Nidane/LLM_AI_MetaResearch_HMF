from pathlib import Path
import json
import subprocess
import zipfile
import xml.etree.ElementTree as ET
import shutil

manifest_path = Path('/home/ubuntu/work_rob/pmid_manifest.json')
manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
out_dir = Path('/home/ubuntu/work_rob/extracted_text')
out_dir.mkdir(exist_ok=True)
lo_dir = Path('/home/ubuntu/work_rob/libreoffice_txt')
lo_dir.mkdir(exist_ok=True)

NS = {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}

def extract_pdf(path: Path) -> str:
    txt_path = out_dir / (path.stem + '.txt')
    try:
        subprocess.run(['pdftotext', '-layout', str(path), str(txt_path)], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        return txt_path.read_text(encoding='utf-8', errors='replace')
    except Exception as e:
        return f'[PDF text extraction failed for {path.name}: {e}]\n'

def extract_docx(path: Path) -> str:
    try:
        pieces = []
        with zipfile.ZipFile(path) as z:
            for name in ['word/document.xml']:
                xml = z.read(name)
                root = ET.fromstring(xml)
                for para in root.findall('.//w:p', NS):
                    texts = [t.text or '' for t in para.findall('.//w:t', NS)]
                    if texts:
                        pieces.append(''.join(texts))
        return '\n'.join(pieces)
    except Exception as e:
        return f'[DOCX extraction failed for {path.name}: {e}]\n'

def extract_doc_with_libreoffice(path: Path) -> str:
    try:
        before = set(lo_dir.iterdir())
        subprocess.run(['libreoffice', '--headless', '--convert-to', 'txt:Text', '--outdir', str(lo_dir), str(path)], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60)
        txt_path = lo_dir / (path.stem + '.txt')
        if txt_path.exists():
            return txt_path.read_text(encoding='utf-8', errors='replace')
        after = set(lo_dir.iterdir()) - before
        for p in after:
            if p.suffix.lower() == '.txt':
                return p.read_text(encoding='utf-8', errors='replace')
        return f'[DOC conversion produced no txt for {path.name}]\n'
    except Exception as e:
        return f'[DOC extraction failed for {path.name}: {e}]\n'

def extract_file(path_str: str) -> str:
    path = Path(path_str)
    ext = path.suffix.lower()
    if ext == '.pdf':
        return extract_pdf(path)
    if ext == '.docx':
        return extract_docx(path)
    if ext == '.doc':
        return extract_doc_with_libreoffice(path)
    if ext in ['.jpg', '.jpeg', '.png']:
        return f'[Image supplementary file requiring visual review: {path}]\n'
    return f'[Unsupported file type: {path}]\n'

summary = []
for pmid, entry in sorted(manifest.items(), key=lambda kv: int(kv[0])):
    packet = []
    main = entry.get('main_paper')
    if main:
        p = Path(main['path'])
        txt = extract_file(main['path'])
        packet.append(f'\n===== MAIN PAPER: {p.name} =====\n{txt}\n')
    for supp in entry.get('supplementary_files', []):
        p = Path(supp['path'])
        txt = extract_file(supp['path'])
        packet.append(f'\n===== SUPPLEMENTARY FILE: {p.name} =====\n{txt}\n')
    combined = ''.join(packet)
    out = out_dir / f'{pmid}_combined.txt'
    out.write_text(combined, encoding='utf-8')
    summary.append({'pmid': pmid, 'combined_text_path': str(out), 'chars': len(combined), 'supplement_count': len(entry.get('supplementary_files', []))})

summary_path = Path('/home/ubuntu/work_rob/text_extraction_summary.json')
summary_path.write_text(json.dumps(summary, indent=2), encoding='utf-8')
print(json.dumps(summary, indent=2))
