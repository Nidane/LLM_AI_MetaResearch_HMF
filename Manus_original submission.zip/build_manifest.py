from pathlib import Path
import json
import re

base = Path('/home/ubuntu/work_rob/allpapers/all papers')
manifest = {}
for path in sorted(base.iterdir()):
    if not path.is_file():
        continue
    m = re.match(r'^(\d+)(?:_(Supplementary.*))?\.(\w+)$', path.name, flags=re.I)
    if not m:
        continue
    pmid, supp_label, ext = m.groups()
    entry = manifest.setdefault(pmid, {'pmid': pmid, 'main_paper': None, 'supplementary_files': []})
    item = {'path': str(path), 'filename': path.name, 'extension': ext.lower()}
    if supp_label:
        item['supplement_label'] = supp_label
        entry['supplementary_files'].append(item)
    else:
        entry['main_paper'] = item

out = Path('/home/ubuntu/work_rob/pmid_manifest.json')
out.write_text(json.dumps(manifest, indent=2), encoding='utf-8')
print(f'Wrote {out} with {len(manifest)} PMID groups')
for pmid, entry in manifest.items():
    print(pmid, 'main=', entry['main_paper']['filename'] if entry['main_paper'] else None, 'supps=', len(entry['supplementary_files']))
